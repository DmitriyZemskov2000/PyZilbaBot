
import unittest
from pyzilbabot import Bot

class TestBot(unittest.TestCase):
    def test_init(self):
        bot = Bot("test:token")
        self.assertEqual(bot.token, "test:token")
        self.assertEqual(bot.base_url, "https://zilba.draklor.su")
