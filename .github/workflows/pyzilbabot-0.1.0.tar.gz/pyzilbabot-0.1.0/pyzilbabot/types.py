
"""
Типы данных для Zilba API.
"""

from typing import Optional, List, Dict, Any
from dataclasses import dataclass


@dataclass
class User:
    id: int
    username: str
    display_name: str
    is_bot: bool = False
    avatar: Optional[str] = None
    bio: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "User":
        return cls(
            id=data.get("id"),
            username=data.get("username", ""),
            display_name=data.get("display_name", "User"),
            is_bot=data.get("is_bot", False),
            avatar=data.get("avatar"),
            bio=data.get("bio"),
        )


@dataclass
class Chat:
    id: int
    type: str
    name: Optional[str] = None
    username: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Chat":
        return cls(
            id=data.get("id"),
            type=data.get("type", "private"),
            name=data.get("name"),
            username=data.get("username"),
        )


@dataclass
class Message:
    id: int
    chat_id: int
    sender_id: int
    type: str
    content: Optional[str] = None
    sender_name: Optional[str] = None
    sender_username: Optional[str] = None
    media_url: Optional[str] = None
    media_name: Optional[str] = None
    media_size: Optional[int] = None
    duration: Optional[float] = None
    encrypted: bool = False
    reply_to: Optional[int] = None
    created_at: float = 0
    chat: Optional[Chat] = None
    sender: Optional[User] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Message":
        return cls(
            id=data.get("id"),
            chat_id=data.get("chat_id"),
            sender_id=data.get("sender_id"),
            type=data.get("type", "text"),
            content=data.get("content"),
            sender_name=data.get("sender_name"),
            sender_username=data.get("sender_username"),
            media_url=data.get("media_url"),
            media_name=data.get("media_name"),
            media_size=data.get("media_size"),
            duration=data.get("duration"),
            encrypted=data.get("encrypted", False),
            reply_to=data.get("reply_to"),
            created_at=data.get("created_at", 0),
            chat=Chat.from_dict(data.get("chat", {})) if data.get("chat") else None,
            sender=User.from_dict(data.get("from", {})) if data.get("from") else None,
        )


@dataclass
class Update:
    update_id: int
    message: Optional[Message] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Update":
        return cls(
            update_id=data.get("update_id"),
            message=Message.from_dict(data.get("message", {})) if data.get("message") else None,
        )


@dataclass
class InlineKeyboardButton:
    text: str
    callback_data: Optional[str] = None
    url: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {"text": self.text}
        if self.callback_data:
            result["callback_data"] = self.callback_data
        if self.url:
            result["url"] = self.url
        return result


@dataclass
class InlineKeyboardMarkup:
    inline_keyboard: List[List[InlineKeyboardButton]]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "inline_keyboard": [
                [btn.to_dict() for btn in row]
                for row in self.inline_keyboard
            ]
        }


@dataclass
class KeyboardButton:
    text: str


@dataclass
class ReplyKeyboardMarkup:
    keyboard: List[List[KeyboardButton]]
    resize_keyboard: bool = True
    one_time_keyboard: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "keyboard": [
                [{"text": btn.text} for btn in row]
                for row in self.keyboard
            ],
            "resize_keyboard": self.resize_keyboard,
            "one_time_keyboard": self.one_time_keyboard,
        }
