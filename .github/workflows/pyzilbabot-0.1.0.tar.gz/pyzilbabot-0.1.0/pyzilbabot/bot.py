
"""
Основной класс Bot для работы с Zilba API.
"""

import json
import time
import requests
from typing import Optional, List, Dict, Any, Callable, Union
from threading import Thread, Event

from .types import Message, Update, User, InlineKeyboardMarkup, ReplyKeyboardMarkup
from .exceptions import APIError, TokenError


class Bot:
    """Клиент для работы с Zilba Bot API."""

    def __init__(self, token: str, base_url: str = "https://zilba.draklor.su"):
        self.token = token
        self.base_url = base_url.rstrip('/')
        self._handlers: List[Dict[str, Any]] = []
        self._polling_thread: Optional[Thread] = None
        self._stop_event = Event()
        self._offset = 0
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        })

    def _request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict:
        url = f"{self.base_url}/api/bot/{endpoint.lstrip('/')}"
        try:
            resp = self._session.request(method, url, json=data)
        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error: {e}")

        if resp.status_code == 401:
            raise TokenError("Invalid or expired bot token")

        try:
            result = resp.json()
        except json.JSONDecodeError:
            raise APIError(f"Invalid response: {resp.text[:200]}")

        if resp.status_code != 200 or not result.get("ok"):
            error = result.get("error") or result.get("description") or "Unknown API error"
            raise APIError(f"[{resp.status_code}] {error}")

        return result

    def get_me(self) -> User:
        result = self._request("GET", "getMe")
        return User.from_dict(result.get("bot", {}))

    def send_message(
        self,
        chat_id: int,
        text: str,
        reply_to: Optional[int] = None,
        reply_markup: Optional[Union[InlineKeyboardMarkup, ReplyKeyboardMarkup]] = None
    ) -> Message:
        payload = {"chat_id": chat_id, "text": text}
        if reply_to:
            payload["reply_to"] = reply_to
        if reply_markup:
            payload["reply_markup"] = reply_markup.to_dict()

        result = self._request("POST", "sendMessage", payload)
        return Message.from_dict(result.get("message", {}))

    def answer_callback_query(self, callback_query_id: str, text: Optional[str] = None):
        payload = {"callback_query_id": callback_query_id}
        if text:
            payload["text"] = text
        self._request("POST", "answerCallbackQuery", payload)

    def get_updates(self, offset: int = 0, limit: int = 100) -> List[Update]:
        result = self._request("GET", f"getUpdates?offset={offset}&limit={limit}")
        return [Update.from_dict(u) for u in result.get("result", [])]

    def set_webhook(self, url: str):
        return self._request("POST", "setWebhook", {"url": url})

    def message_handler(self, **kwargs):
        def decorator(func: Callable):
            self._handlers.append({
                "func": func,
                "commands": kwargs.get("commands", []),
                "content_types": kwargs.get("content_types", []),
                "chat_types": kwargs.get("chat_types", []),
            })
            return func
        return decorator

    def _process_update(self, update: Update) -> bool:
        if not update.message:
            return False

        msg = update.message
        processed = False

        for handler in self._handlers:
            if handler["commands"]:
                if not msg.text or not msg.text.startswith('/'):
                    continue
                command = msg.text.split()[0][1:]
                if command not in handler["commands"]:
                    continue

            if handler["content_types"]:
                if msg.text and "text" not in handler["content_types"]:
                    continue
                if msg.media_url and "media" not in handler["content_types"]:
                    continue

            if handler["chat_types"]:
                if msg.chat.type not in handler["chat_types"]:
                    continue

            try:
                handler["func"](msg)
            except Exception as e:
                print(f"Error in handler: {e}")
            processed = True
            break

        return processed

    def polling(self, interval: float = 1.0):
        print("🤖 Bot started polling...")
        while not self._stop_event.is_set():
            try:
                updates = self.get_updates(offset=self._offset)
                for update in updates:
                    if update.update_id >= self._offset:
                        self._offset = update.update_id + 1
                        self._process_update(update)
            except APIError as e:
                print(f"⚠️ API error: {e}")
                time.sleep(interval * 2)
            except Exception as e:
                print(f"⚠️ Unexpected error: {e}")
                time.sleep(interval)
            time.sleep(interval)

    def start_polling(self, interval: float = 1.0):
        if self._polling_thread and self._polling_thread.is_alive():
            return
        self._stop_event.clear()
        self._polling_thread = Thread(target=self.polling, args=(interval,), daemon=True)
        self._polling_thread.start()

    def stop_polling(self):
        self._stop_event.set()
        if self._polling_thread:
            self._polling_thread.join(timeout=5)

    def run(self, interval: float = 1.0):
        try:
            me = self.get_me()
            print(f"✅ Bot started: @{me.username} ({me.display_name})")
            self.polling(interval)
        except KeyboardInterrupt:
            print("\n🛑 Bot stopped")
            self.stop_polling()
