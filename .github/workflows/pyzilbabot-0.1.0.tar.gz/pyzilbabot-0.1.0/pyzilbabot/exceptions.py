
"""
Исключения PyZilbaBot.
"""


class PyZilbaBotError(Exception):
    pass


class APIError(PyZilbaBotError):
    pass


class TokenError(PyZilbaBotError):
    pass


class WebhookError(PyZilbaBotError):
    pass
