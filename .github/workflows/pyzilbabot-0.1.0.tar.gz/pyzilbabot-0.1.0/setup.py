
from setuptools import setup, find_packages

setup(
    name="pyzilbabot",
    version="0.1.0",
    author="Zilba Team",
    author_email="dima13@draklor.ru",
    description="Python библиотека для создания ботов для Zilba Messenger",
    long_description="Библиотека для создания ботов для Zilba Messenger. Поддерживает отправку сообщений, клавиатуры, обработку команд.",
    long_description_content_type="text/markdown",
    url="https://zilba.draklor.su",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    project_urls={
        "Source": "https://github.com/zilba/pyzilbabot",
        "Bug Reports": "https://github.com/zilba/pyzilbabot/issues",
    },
)
